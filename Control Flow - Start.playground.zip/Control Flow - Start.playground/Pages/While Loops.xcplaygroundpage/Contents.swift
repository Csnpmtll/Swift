var i = 10
while  i < 10 {
    print(i)
    i+=1
}
print("---")

i=1
repeat{
    print(i)
    if i==5 {
        break
    }
    i+=1
}while i<10
    print("- * - * -")
