//: [Previous](@previous)
//: # Challenge Time - While Loops! 😃


/*:
 Create a variable named `count` and set it equal to 0. Create a `while` loop with the condition `count < 10` which prints out "Count is `X`" (where `X` is replaced with the `count` value) and then increments `count` by 1.
 */
// TODO: Write solution here
var count = 0
while count<10 {
    let X=count
    print("Count is \(X)")
    count+=1
}

print("---------------------------------")
/*:
 **Simulate the roll of a six-sided die, and roll until you get a 6**
 Create a variable named count and set it equal to 0. Create another variable named roll and make it an Int. Create a repeat-while loop. Inside the loop, set roll equal to `Int.random(in: 1...6)`, which means to pick a random number between 1 and 6. Then increment count by 1. Finally, print "After `X` rolls, roll is `Y`" (where `X` is the value of count and `Y` is the value of roll). Set the loop condition so that the loop finishes when the first 6 is rolled.
 */
// TODO: Write solution here
var count1=0
repeat{
    var roll = Int.random(in: 1...6)
    if roll == 6 {
        break
    }
    let X = count1
    let Y = roll
    print("After \(X) rolls, roll is \(Y)")
    count1+=1
}while true

print("---------------------------------")
/*:
 **Extra Challenge!**
 Stop the execution of the loop when `count` is greater than 5. You've learned two ways to do this so far in this course!
 */
var count2=0
var roll = 0
repeat{
    roll = Int.random(in: 1...6)
    if count2 > 5 {
        break
    }
    let X = count2
    let Y = roll
    print("After \(X) rolls, roll is \(Y)")
    count2+=1
}while count2 < 6


//: [Next](@next)
