//: [Previous](@previous)

import Foundation

//var str = "Hello, playground"
//var str1 = "Hello, playground"
//var str2 = "Hello, playground"
//var str3 = "Hello, playground"
//var str4 = "Hello, playground"
//var str5 = "Hello, playground"
//var str6 = "Hello, playground"
//: [Next](@next)
