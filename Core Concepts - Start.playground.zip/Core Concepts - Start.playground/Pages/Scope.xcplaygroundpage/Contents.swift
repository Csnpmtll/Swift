//: [Previous](@previous)

/*:
 ### SCOPE
 Imagine you are starting a cat sitting business, and you want to calculate the fee to charge your clients when you look after thair cats.
 
 You earn $25 for every hour up to 40 hours, and $50 for every hour after that.
 */

let maxStandardHours = 40
let standardRate = 25
let overtimeRate = 50
/*:
 With the help of those three constants, create an alogrithm to calculate how much to charge a client.
 */
let hoursWorked = 45

let price : Int

if(hoursWorked>maxStandardHours){
    let extraHour = hoursWorked-maxStandardHours
    price=(maxStandardHours*standardRate)+(extraHour*overtimeRate)
}else{
    price=hoursWorked*standardRate
}
print(price)


//: [Next](@next)
