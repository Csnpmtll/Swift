//: [Previous](@previous)
let yes=true
let no=false

let oneIsGreaterThanTwo = 1>2
let oneIsLessThanTwo = 1<2

6>=6

let oneEqualIsTwo = 1 == 2
let catDoesNotEqualDog = "Car" != "Cat"

let catComesBeforeCat = "Car" < "Cat"

let waterIsWet = true
let fireIsCold = false
let catsAreCute = true

!waterIsWet

let allAreTrue = waterIsWet && fireIsCold && catsAreCute

let antAreTrue = waterIsWet || fireIsCold || catsAreCute

let andCombo = 1 < 2 && 4 < 3
let orCombo = "Cat" == "Dog" || "Godzilla" == "Godzilla"

let a = 5
let b = 10
let min = a < b ? a : b

//: [Next](@next)
