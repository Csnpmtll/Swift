//: Playground - noun: a place where people can play
import UIKit
let constant=0  //let=constant value

let a:Int=3
let a1=3

let b:String="a"
let b1="a"

let c:Float=4.00
let c1=4.00

var string = "Hello, playground"
string = "Hi!"

var currentValue = 50
var targetValue = 55

var difference = currentValue - targetValue
if difference < 0 {
  difference *= -1
}
print(difference)
